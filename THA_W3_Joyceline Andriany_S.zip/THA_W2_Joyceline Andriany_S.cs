﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = nameTextBox.Text;
            string ageString = ageTextBox.Text;
            string email = emailTextBox.Text;
            string phoneNumber = phoneNumberTextBox.Text;

            int age = 0;
            bool isAgeValid = int.TryParse(ageString, out age);

            if (isAgeValid)
            {
                string message = string.Format("Name: {0}\nEmail: {1}\nPhone Number: {2}\nYou are {3}", name, email, phoneNumber, age >= 18 ? "An Adult " : "A Minor ");
                MessageBox.Show(message, "Details", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Please enter a valid age", "Invalid Age", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            nameTextBox.Text = "";
            ageTextBox.Text = "";
            emailTextBox.Text = "";
            phoneNumberTextBox.Text = "";
        }
    }
}
